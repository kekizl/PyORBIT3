#include <iostream>
#include <cstdlib>
#include <ctime>
#include "kernel.cuh" // Include the header file with function declarations
#include <chrono>

void matrixVectorMultiplyCPU(double *vectors, double *matrix, double *results, int numVectors, int vectorSize, int matrixSize) {
    for (int i = 0; i < numVectors; ++i) {
        for (int j = 0; j < vectorSize; ++j) {
            double dotProduct = 0.0;
            for (int k = 0; k < vectorSize; ++k) {
                dotProduct += matrix[j * matrixSize + k] * vectors[i * vectorSize + k];
            }
            results[i * vectorSize + j] = dotProduct;
        }
    }
}

void initData(double* h_vectors, double* h_matrix, int numVectors, int vectorSize, int matrixSize) {
    for (int i = 0; i < numVectors; ++i) {
        for (int j = 0; j < vectorSize; ++j) {
            h_vectors[i * vectorSize + j] = i; 
        }
    }

    srand(time(nullptr)); 
    for (int i = 0; i < matrixSize; ++i) {
        for (int j = 0; j < matrixSize; ++j) {
            h_matrix[i * matrixSize + j] = rand() % 10; 
	    }
    }
}

void printMatrix(double* h_matrix, int matrixSize) {
    std::cout << "Matrix:" << std::endl;
    for (int i = 0; i < matrixSize; ++i) {
        for (int j = 0; j < matrixSize; ++j) {
            std::cout << h_matrix[i * matrixSize + j] << " ";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

void printVectors(double* h_vectors, int numVectors, int vectorSize) {
    std::cout << "Vectors:" << std::endl;
    for (int i = 0; i < numVectors; ++i) {
        for (int j = 0; j < vectorSize; ++j) {
            std::cout << h_vectors[i * vectorSize + j] << " ";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

void printResults(double* h_results, int numVectors, int vectorSize) {
    std::cout << "Results:" << std::endl;
    for (int i = 0; i < numVectors; ++i) {
        std::cout << "Vector " << i << ": ";
        for (int j = 0; j < vectorSize; ++j) {
            std::cout << h_results[i * vectorSize + j] << " ";
        }
        std::cout << std::endl;
    }
}

int main() {
    const int numVectors = 1000000;
    const int vectorSize = 6;
    const int matrixSize = 6;
   
    // Host data
    double *h_vectors = new double[numVectors * vectorSize];
    double *h_matrix = new double[matrixSize * matrixSize];
    double *h_results = new double[numVectors * vectorSize];

    // Initialize host data
    initData(h_vectors, h_matrix, numVectors, vectorSize, matrixSize);

    // Print matrix and vectors
    printMatrix(h_matrix, matrixSize);
    printVectors(h_vectors, numVectors, vectorSize);
 
    // Run matrix-vector multiplication on CPU and measure time
    auto cpuTimeStart = std::chrono::high_resolution_clock::now();
    matrixVectorMultiplyCPU(h_vectors, h_matrix, h_results, numVectors, vectorSize, matrixSize);
    auto cpuTimeEnd = std::chrono::high_resolution_clock::now();
    auto cpuDuration = std::chrono::duration_cast<std::chrono::microseconds>(cpuTimeEnd - cpuTimeStart).count();

    // Run matrix-vector multiplication on GPU and measure time
    auto gpuTimeStart = std::chrono::high_resolution_clock::now();
	// Device data
    double *d_vectors, *d_matrix, *d_results;
    cudaAllocateMemory(&d_vectors, &d_matrix, &d_results, numVectors, vectorSize, matrixSize); // Allocate memory for one batch

    runMatrixVectorMultiplyKernel(d_vectors, d_matrix, d_results, numVectors, vectorSize, matrixSize);
    cudaFreeAll(d_matrix, d_vectors, d_results);
    auto gpuTimeEnd = std::chrono::high_resolution_clock::now();
    auto gpuDuration = std::chrono::duration_cast<std::chrono::microseconds>(gpuTimeEnd - gpuTimeStart).count();
 
    // Print execution times
    std::cout << numVectors << " particles" << std::endl;
    std::cout << "CPU Execution Time: " << cpuDuration << " microseconds" << std::endl;
    std::cout << "GPU Execution Time: " << gpuDuration << " microseconds" << std::endl;

    delete[] h_vectors;
    delete[] h_matrix;
    delete[] h_results;

    return 0;
}
